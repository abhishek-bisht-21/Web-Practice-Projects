class Student
    {
        int Roll;
        String Name;
        double Marks;

        Student(int R,String N,double M)                 // Constructor 1
        {
            Roll = R;
            Name = N;
            Marks = M;
        }

        Student(String N,double M,int R)                  // Constructor 2
        {
            Roll = R;
            Name = N;
            Marks = M;
        }

        void Display()
        {
            System.out.print("\n\t" + Roll+"\t" + Name+"\t" + Marks);
        }
    }

    class Constructor
    {
        public static void main(String[] args)
        {
            Student S1 = new Student(1,"Kumar",78.53);        
            Student S2 = new Student("Sumit",89.42,2);          

            System.out.print("\n\tRoll\tName\tMarks\n");
            S1.Display();
            S2.Display();
        }
}