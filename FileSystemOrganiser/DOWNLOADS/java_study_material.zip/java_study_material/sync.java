class Transfer{
 public void sendMessage(String message ){
          System.out.println(message + :is sending");
    try{
      Thread.sleep(1000);
    }
   catch(Exception e){
     System.out.println(e);
    }
  System.out.println(message + "is sent");
}}
class MessageTransfer extends Thread{
   private String message;
   Transfer msgtransfer;
     public MessageTransfer(String msg,Transfer trans){
      message= msg;
      msgtransfer=trans;
}
public void run(){
     //synchronized(msgtransfer){
     msgtransfer.sendMessage(message);}}
//}

public class Sync{
	public static void main(String args[]){
	Transfer trans= new Transfer();
	MessageTransfer msg1= new MessageTransfer("hello",trans);
	MessageTransfer msg2= new MessageTransfer("World",trans);
	MessageTransfer msg3= new MessageTransfer("java",trans);
msg1.start();
msg2.start();
msg3.start();
}}

 
    
