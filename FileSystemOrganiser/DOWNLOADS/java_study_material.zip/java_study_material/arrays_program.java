import java.util.Scanner;
class Students{
        public static void main(String[] args) {
  	  
          
      // allocation and declaration
          int arr []= new int[5]; 
          Scanner s=new Scanner(System.in);
          arr[0]= s.nextInt();
System.out.println("value of zero index is" +arr[0]);

        }
}

/////////////////////

class GFG { 
	public static void main(String[] args) 
	{ 

		int[][] arr = new int[10][20]; 
		arr[0][0] = 10; 

		System.out.println("arr[0][0] = " + arr[0][0]); 
	} 
} 



////////multidimensional

class multiDimensional 
{ 
    public static void main(String args[]) 
    { 
        // declaring and initializing 2D array 
        int arr[][] = { {2,7,9},{3,6,1},{7,4,2} }; 
        for (int i=0; i< 3 ; i++) 
        { 
            for (int j=0; j < 3 ; j++) 
                System.out.print(arr[i][j] + " "); 
  
            System.out.println(); 
        } 
    } 
} 
  