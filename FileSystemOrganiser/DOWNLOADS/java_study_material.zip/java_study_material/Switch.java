class Switch{
public static void main(String jyoti[]){

int num=60;
switch(num){
case 20:
System.out.println("case is 20");
break;
 case 40:
System.out.println("case is 40");
break;

case 60:
System.out.println("case is 60");
break;
 default:
System.out.println("default case");
}}}
