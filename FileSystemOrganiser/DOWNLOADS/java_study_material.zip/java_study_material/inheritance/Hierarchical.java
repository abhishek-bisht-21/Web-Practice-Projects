class A {
    int x = 10;
}

class B extends A {

    void display() {
        System.out.println("The value of x into B class is:" + x);
    }
}

class Main extends A {

    void display() {
        System.out.println("The value of x into Main class is:" + x);
    }}
class Hierarchical {
    public static void main(String args[]) {
        B obj1 = new B();
        obj1.display();
        Main obj2 = new Main();
        obj2.display();
    }
}