class Flower{  
    int id;  
    String name;    
    Flower(int i,String n){  
    id = i;  
    name = n;  
    }   
    void display()
    {
    System.out.println(id+" "+name);
    }   
    public static void main(String args[]){      
    Flower s1 = new Flower (1,"Lily");  
    Flower s2 = new Flower (2,"Lotus");  
     
    s1.display();  
    s2.display();  
   }  
}