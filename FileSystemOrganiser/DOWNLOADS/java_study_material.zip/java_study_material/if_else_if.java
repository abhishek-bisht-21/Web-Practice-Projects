class Qwe{
public static void main(String args[]){
int marks=90;
char grade;
 if(marks>=80){
   grade='A';
}
else if(marks>=60){
grade='B';
}
else{
grade='F';
}
System.out.println("Grade is" +grade);
}}



Q1) Write a Java program to get a number from the user and print whether it is positive or negative.

import java.util.Scanner;
class First {
public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input number: ");
        int input = in.nextInt();

        if (input > 0)
        {
            System.out.println("Number is positive");
        }
        else if (input < 0)
        {
            System.out.println("Number is negative");
        }
        else
        {
            System.out.println("Number is zero");
        }
    }
}

Q2) Take three numbers from the user and print the greatest number.

import java.util.Scanner;
class Second{
 public static void main(String[] args) {
  Scanner in = new Scanner(System.in);
   
  System.out.print("Input the 1st number: ");
  int num1 = in.nextInt();
   
  System.out.print("Input the 2nd number: ");
  int num2 = in.nextInt();
   
  System.out.print("Input the 3rd number: ");
  int num3 = in.nextInt();
   
   
  if (num1 > num2){
   if (num1 > num3)
    System.out.println("The greatest: " + num1);
   
  if (num2 > num1)
   if (num2 > num3)
    System.out.println("The greatest: " + num2);
   
  if (num3 > num1)
   if (num3 > num2)
    System.out.println("The greatest: " + num3);
 }
}