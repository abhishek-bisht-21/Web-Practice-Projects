

class Arraay
{ 
	public static void main(String[] args) 
					throws IOException 
	{ 
		
		int n = 5; 

		ArrayList<Integer> arrli = new ArrayList<Integer>(n); 

		for (int i=1; i<=n; i++) 
			arrli.add(i); 
		System.out.println(arrli); 
		arrli.remove(3); 
		System.out.println(arrli); 
		
	} 
} 
