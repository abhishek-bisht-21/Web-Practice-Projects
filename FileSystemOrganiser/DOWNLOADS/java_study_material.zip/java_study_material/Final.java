class Final
{
final int hours=24;
void fun(){
System.out.println(hours);
}
void sum(){
hours=30;
System.out.println(hours);
}
 public static void main(String args[])
   {
      
   Final f=new Final();
  f.fun();
f.sum();

   }

}
