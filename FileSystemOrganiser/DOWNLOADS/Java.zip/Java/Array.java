import java.util.Scanner;
class Array
{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
int i=s.nextInt();
int j=s.nextInt();
int arr[][]= new int[i][j];


for (int k =0; k<i; k++){
 for (int l=0; l<j;l++){
   
  System.out.print(k + "," +l +"     ");
} 
 System.out.println();
} 
}}
