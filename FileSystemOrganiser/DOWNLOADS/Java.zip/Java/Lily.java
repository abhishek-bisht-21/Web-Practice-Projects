
class Lily{  

Lily()
{
System.out.println("Lily is a flower");
}  
public static void main(String args[])
{  
Lily l=new Lily();  
}  
} 